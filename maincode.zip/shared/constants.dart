import 'package:flutter/material.dart';

class Constants {
  static String appId = "1:534387528030:web:58517872659e2e8b2cffcf";
  static String apiKey = "AIzaSyCkf-OLOoMIB208OgrmsllC_xKMUHd-MEE";
  static String messagingSenderId = "534387528030";
  static String projectId = "talkienew";
  final primaryColor = const Color(0xFF4285F4);
}
