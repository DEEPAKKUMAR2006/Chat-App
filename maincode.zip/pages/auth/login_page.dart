import 'package:talkienew/helper/helper_function.dart';
import 'package:talkienew/pages/auth/register_page.dart';
import 'package:talkienew/pages/home_page.dart';
import 'package:talkienew/service/auth_service.dart';
import 'package:talkienew/service/database_service.dart';
import 'package:talkienew/widgets/widgets.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  bool _isLoading = false;
  AuthService authService = AuthService();
  bool passwordVisible = false;

  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
          body: _isLoading
              ? Center(
            child: CircularProgressIndicator(
                color: Theme.of(context).primaryColor
            ),
          )
              : SingleChildScrollView(
            child: Padding(
                padding :const EdgeInsets.symmetric(vertical: 80,horizontal: 20),
                child: Form(
                    key:formKey,
                    child:Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Text("Talkie", style: TextStyle(fontFamily: "Times New Roman",fontSize: 30,fontWeight: FontWeight.bold,color: Colors.blue),
                        ),
                        const SizedBox(height:10),
                        const Text("Login to see who is talking" ,
                          style: TextStyle(fontFamily: "Times New Roman",
                              fontSize: 20,
                              color: Colors.redAccent
                          ),
                        ),
                        const SizedBox(height:10),
                        Image.asset('assets/login1.jpg',height: 300,width: 400,),
                        const SizedBox(height:50),
                        TextFormField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            hintText: 'Email',
                            prefixIcon:const Icon(Icons.email),
                          ),
                          onChanged:(val){
                            setState(() {
                              email=val;
                            }
                            );
                          },
                          validator: (val){
                            return RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(val!) ? null : "Please enter a valid email";
                          },
                        ),
                        const SizedBox(height:30),

                        TextFormField(
                          obscuringCharacter: '*',
                          obscureText: !passwordVisible,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            hintText: 'Password',
                            prefixIcon: const Icon(Icons.lock_rounded),
                            suffixIcon: IconButton(
                              icon: Icon(passwordVisible ? Icons.visibility : Icons.visibility_off),
                              onPressed: () {
                                setState(() {
                                  passwordVisible = !passwordVisible;
                                });
                              },
                            ),
                          ),
                          validator: (val) {
                            if (val!.length < 6) {
                              return "Password must be at least 6 characters long";
                            } else {
                              return null;
                            }
                          },
                          onChanged: (val) {
                            setState(() {
                              password = val;
                            });
                          },
                        ),

                        Padding(padding: const EdgeInsets.only(left:5,top:40,right: 5,bottom: 3), child:TextButton(onPressed:()=> login(),
                            style:ButtonStyle(
                              padding: MaterialStateProperty.all<EdgeInsets>
                                (
                                  const EdgeInsets.only(
                                      left: 120,
                                      right: 120,
                                      top:10,
                                      bottom: 10
                                  )
                              ),
                              backgroundColor:MaterialStateProperty.all<Color>(
                                  Colors.blue),
                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                            ),
                            child:const Text(
                                "Sign in",style: TextStyle(color: Colors.white,fontSize: 16)
                            )
                        ),
                        ),
                        Text.rich(
                            TextSpan(
                                text: "Don't have an account?  ",
                                style:const TextStyle(fontFamily: "Times New Roman",fontSize: 15),

                                children: <TextSpan>[
                                  TextSpan(
                                      text:"Register now",
                                      style: const TextStyle(decoration: TextDecoration.underline),
                                      recognizer: TapGestureRecognizer()..onTap=(){nextScreen(context, const RegisterPage());
                                      }
                                  ),
                                ]
                            )
                        )
                      ],
                    )
                )
            ),
          )
      );
  }

  login() async {
    if (formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      await authService
          .loginWithUserNameandPassword(email, password)
          .then((value) async {
        if (value == true) {
          QuerySnapshot snapshot =
          await DatabaseService(uid: FirebaseAuth.instance.currentUser!.uid)
              .gettingUserData(email);
          await HelperFunctions.saveUserLoggedInStatus(true);
          await HelperFunctions.saveUserEmailSF(email);
          await HelperFunctions.saveUserNameSF(snapshot.docs[0]['fullName']);
          nextScreenReplace(context, const HomePage());
        } else {
          showSnackbar(context, Colors.blue, value);
          setState(() {
            _isLoading = false;
          });
        }
      });
    }
  }
}
