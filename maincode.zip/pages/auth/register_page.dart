import 'package:talkienew/helper/helper_function.dart';
import 'package:talkienew/pages/auth/login_page.dart';
import 'package:talkienew/pages/home_page.dart';
import 'package:talkienew/service/auth_service.dart';
import 'package:talkienew/widgets/widgets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({Key? key}) : super(key: key);

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  bool _isLoading = false;
  final formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  String fullName = "";
  AuthService authService = AuthService();
  bool passwordVisible = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar:AppBar(),
        body:
        _isLoading ? const Center(child: CircularProgressIndicator(color: Colors.blue,)) : SingleChildScrollView(
          child: Padding(
              padding :const EdgeInsets.symmetric(vertical: 80,horizontal: 20),
              child: Form(
                  key:formKey,
                  child:Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text("Talkie", style: TextStyle(fontFamily: "Times New Roman",fontSize: 30,fontWeight: FontWeight.bold,color: Colors.blue),
                      ),
                      const SizedBox(height:10),
                      const Text("Register now to chat and discover more" ,style: TextStyle(fontFamily: "Times New Roman",fontSize: 15,color: Colors.redAccent),

                      ),
                      const SizedBox(height:10),
                      const Image(
                        image: AssetImage("assets/login1.png"),
                        height: 200,
                        width: 400,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          hintText: 'Full Name',
                          prefixIcon:const Icon(Icons.account_box_rounded),
                        ),
                        onChanged:(val){
                          setState(() {
                            fullName=val;
                          }
                          );
                        },
                        validator: (val){
                          if (val!.isEmpty){
                            return "Name can't be empty";
                          }
                          else{
                            return null;
                          }
                        },
                      ),
                      const SizedBox(height:30),
                      TextFormField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          hintText: 'Email',
                          prefixIcon:const Icon(Icons.email),
                        ),
                        onChanged:(val){
                          setState(() {
                            email=val;
                          }
                          );
                        },
                        validator: (val){
                          return RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(val!) ? null : "Please enter a valid email";
                        },
                      ),
                      const SizedBox(height:30),
                      TextFormField(
                          obscuringCharacter: '*', // defaults to *
                          obscureText: !passwordVisible,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            hintText: 'Password',
                            prefixIcon: const Icon(Icons.lock_rounded),
                            suffixIcon: IconButton(
                              icon: Icon(passwordVisible ? Icons.visibility : Icons.visibility_off),
                              onPressed: () {
                                setState(() {
                                  passwordVisible = !passwordVisible;
                                });
                              },
                            ),
                          ),
                          validator: (val){
                            if(val!.length<6){
                              return "Password must more than 6 characters";
                            }
                            else{
                              return null;
                            }
                          },
                          onChanged:(val){
                            setState(() {
                              password=val;
                            });
                          }
                      ),

                      Padding(padding: const EdgeInsets.only(left:5,top:40,right: 5,bottom: 3),
                        child:TextButton(onPressed:()=> register() ,

                            style:ButtonStyle(
                              padding: MaterialStateProperty.all<EdgeInsets>
                                (
                                  const EdgeInsets.only(
                                      left: 120,
                                      right: 120,
                                      top:10,
                                      bottom: 10
                                  )
                              ),
                              backgroundColor:MaterialStateProperty.all<Color>(
                                  Colors.blue),
                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                            ),
                            child:const Text(
                                "Register",style: TextStyle(color: Colors.white,fontSize: 16)
                            )
                        ),
                      ),
                      Text.rich(
                          TextSpan(
                              text: "Already have an account?  ",
                              style:const TextStyle(fontFamily: "Times New Roman",fontSize: 15),
                              children: <TextSpan>[
                                TextSpan(
                                    text:"Login now",
                                    style: const TextStyle(decoration: TextDecoration.underline),
                                    recognizer: TapGestureRecognizer()..onTap=(){
                                      nextScreen(context, const LoginPage());
                                    }
                                ),
                              ]
                          )
                      )
                    ],
                  )
              )
          ),
        )
    );
  }

  register() async {
    if (formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      await authService
          .registerUserWithEmailandPassword(fullName, email, password)
          .then((value) async {
        if (value == true) {
          // saving the shared preference state
          await HelperFunctions.saveUserLoggedInStatus(true);
          await HelperFunctions.saveUserEmailSF(email);
          await HelperFunctions.saveUserNameSF(fullName);
          // ignore: use_build_context_synchronously
          nextScreenReplace(context, const HomePage());
        } else {
          showSnackbar(context, Colors.blue, value);
          setState(() {
            _isLoading = false;
          });
        }
      });
    }
  }
}
