import 'package:flutter/services.dart';
import 'package:panara_dialogs/panara_dialogs.dart';
import 'package:talkienew/helper/helper_function.dart';
import 'package:talkienew/pages/auth/login_page.dart';
import 'package:talkienew/pages/profile_page.dart';
import 'package:talkienew/pages/search_page.dart';
import 'package:talkienew/service/auth_service.dart';
import 'package:talkienew/service/database_service.dart';
import 'package:talkienew/widgets/group_tile.dart';
import 'package:talkienew/widgets/widgets.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String userName = "";
  String email = "";
  AuthService authService = AuthService();
  Stream? groups;
  bool _isLoading = false;
  String groupName = "";

  @override
  void initState() {
    super.initState();
    gettingUserData();
  }

  // string manipulation
  String getId(String res) {
    return res.substring(0, res.indexOf("_"));
  }

  String getName(String res) {
    return res.substring(res.indexOf("_") + 1);
  }

  gettingUserData() async {
    await HelperFunctions.getUserEmailFromSF().then((value) {
      setState(() {
        email = value!;
      });
    });
    await HelperFunctions.getUserNameFromSF().then((val) {
      setState(() {
        userName = val!;
      });
    });

    await DatabaseService(uid: FirebaseAuth.instance.currentUser!.uid)
        .getUserGroups()
        .then((snapshot) {
      setState(() {
        groups = snapshot;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(onWillPop: ()async{
      buttonPressed(context);
      return true;
    },child:Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(onPressed: () {
            nextScreen(context, const SearchPage());
          }, icon: const Icon(Icons.search)
          ),
        ],
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "Group", style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),

      drawer: Drawer(
          child: ListView(
            scrollDirection: Axis.vertical,
            padding: const EdgeInsets.symmetric(vertical: 50),
            children: <Widget>[

              Icon(Icons.account_circle_rounded, size: 200,
                  color: Colors.grey[700]),
              const SizedBox(height: 15),
              Text(userName,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold
                ),
              ),

              const SizedBox(height: 30,),
              const Divider(height: 5,),
              ListTile(
                onTap: () {},
                selectedColor: Colors.blue,
                selected: true,
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 5, horizontal: 20
                ),
                leading: const Icon(Icons.group),
                title: const Text("Groups",
                  style: TextStyle(color: Colors.blue, fontSize: 18),),
              ),
              ListTile(
                onTap: () {
                  nextScreenReplace(
                      context, ProfilePage(userName: userName, email: email,));
                },
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 5, horizontal: 20),
                leading: const Icon(Icons.account_circle_rounded),
                title: const Text("Profile",
                  style: TextStyle(color: Colors.black, fontSize: 18),),
              ),
              ListTile(
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 5, horizontal: 20),
                leading: const Icon(Icons.logout_rounded),
                title: const Text("Logout",
                  style: TextStyle(color: Colors.black, fontSize: 18),
                ),
                onTap: () async {
                  PanaraConfirmDialog.show(
                    context,
                    title: "Do you want to logout?",
                    message: "",
                    confirmButtonText: "Confirm",
                    cancelButtonText: "Cancel",
                    onTapCancel: () {
                      Navigator.pop(context);
                    },
                    onTapConfirm: () async {
                      await authService.signOut();
                      // ignore: use_build_context_synchronously
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(
                              builder: (context) => const LoginPage()), (
                          route) => false);
                    },
                    panaraDialogType: PanaraDialogType.normal,
                    barrierDismissible: false,
                  );
                },
              )
            ],
          )
      ),


      body: groupList(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          popUpDialog(context);
        },
        elevation: 0,
        backgroundColor: Theme.of(context).primaryColor,
        child: const Icon(
          Icons.add_box,
          color: Colors.white,
          size: 30,
        ),
      ),
    )
    );
  }

  popUpDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: ((context, setState) {
          return Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              width: 340,
              height: 300,
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "Create a group",
                    textAlign: TextAlign.left,
                    style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 50),
                  _isLoading == true
                      ? Center(
                    child: CircularProgressIndicator(
                      color: Theme.of(context).primaryColor,
                    ),
                  )
                      : TextField(
                    onChanged: (val) {
                      setState(() {
                        groupName = val;
                      }
                      );
                    },
                    style: const TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Theme.of(context).primaryColor,
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Theme.of(context).primaryColor,
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                  const SizedBox(height: 50),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height:40,
                        width:120,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Theme.of(context).primaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: const Text("Cancel"),
                        ),
                      ),

                      SizedBox(
                        height: 40,
                          width: 120,
                        child: ElevatedButton(
                          onPressed: () async {
                            if (groupName != "") {
                              setState(() {
                                _isLoading = true;
                              });
                              DatabaseService(uid: FirebaseAuth.instance.currentUser!.uid,).createGroup(userName, FirebaseAuth.instance.currentUser!.uid, groupName,).whenComplete(() {
                                setState(() {
                                  _isLoading = false;
                                });
                              });
                              Navigator.of(context).pop();
                              PanaraInfoDialog.show(
                                context,
                                title: "Group created successfully",
                                message: "",
                                buttonText: "Okay",
                                onTapDismiss: () {
                                  popup();
                                },
                                panaraDialogType: PanaraDialogType.normal,
                                barrierDismissible: false,
                                imagePath: 'assets/success2.gif'
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Theme.of(context).primaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: const Text("Create"),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        }
        )
        );
      },
    );
  }

  popup(){
    Navigator.pop(context);
  }

  groupList() {
    return StreamBuilder(
      stream: groups,
      builder: (context, AsyncSnapshot snapshot) {
        // make some checks
        if (snapshot.hasData) {
          if (snapshot.data['groups'] != null) {
            if (snapshot.data['groups'].length != 0) {
              return ListView.builder(
                itemCount: snapshot.data['groups'].length,
                itemBuilder: (context, index) {
                  int reverseIndex = snapshot.data['groups'].length - index - 1;
                  return GroupTile(
                      groupId: getId(snapshot.data['groups'][reverseIndex]),
                      groupName: getName(snapshot.data['groups'][reverseIndex]),
                      userName: snapshot.data['fullName']);
                },
              );
            } else {
              return noGroupWidget();
            }
          } else {
            return noGroupWidget();
          }
        } else {
          return Center(
            child: CircularProgressIndicator(
                color: Theme.of(context).primaryColor),
          );
        }
      },
    );
  }

  noGroupWidget() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 25),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () {
              popUpDialog(context);
            },
            child: Icon(
              Icons.add_circle,
              color: Colors.grey[700],
              size: 75,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          const Text(
            "You've not joined any groups, tap on the add icon to create a group or search from top search button.",
            textAlign: TextAlign.center,
          )
        ],
      ),
    );
  }
  buttonPressed(BuildContext context){
     PanaraConfirmDialog.show(
        context,
        title: "Do you want to exit the app?",
        message:"",
        confirmButtonText: "Confirm",
        cancelButtonText: "Cancel",
        onTapCancel: () {
          Navigator.pop(context);
        },
        onTapConfirm: (){
          SystemNavigator.pop();
          },
        panaraDialogType: PanaraDialogType.normal,
        barrierDismissible: false,
      );
    }
  }
