// ignore_for_file: use_build_context_synchronously

import 'package:talkienew/pages/auth/login_page.dart';
import 'package:talkienew/pages/home_page.dart';
import 'package:talkienew/service/auth_service.dart';
import 'package:talkienew/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:panara_dialogs/panara_dialogs.dart';

class ProfilePage extends StatefulWidget {
  final String userName;
  final String email;
  const ProfilePage({Key? key, required this.email, required this.userName})
      : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  AuthService authService = AuthService();
  String userName="";
  String email="";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation:0,
        centerTitle: true,
        title: const Text("Profile",style:TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(onPressed: () {
            nextScreen(context, const HomePage());
          }, icon: const Icon(Icons.home_rounded)
          ),
        ],
      ),


      drawer: Drawer(
          child:ListView(
            padding: const EdgeInsets.symmetric(vertical: 50),
            children: <Widget>[

              Icon(Icons.account_circle_rounded,size: 200,color:Colors.grey[700]),
              const SizedBox(height:15),
              Text(
                userName,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold
                ),
              ),
              const SizedBox(height: 30,),
              const Divider(height: 5,),
              ListTile(
                onTap: (){
                  nextScreen(context, const HomePage());
                },
                contentPadding: const EdgeInsets.symmetric(vertical: 5,horizontal: 20),
                leading:const Icon(Icons.group),
                title: const Text("Groups",style: TextStyle(color: Colors.black,fontSize: 18),),
              ),
              ListTile(
                onTap: (){},
                selectedColor: Colors.blue,
                selected: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 5,horizontal: 20),
                leading:const Icon(Icons.account_circle_rounded),
                title: const Text("Profile",style: TextStyle(color: Colors.blue,fontSize: 18),),
              ),
              ListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 5,horizontal: 20),
                leading:const Icon(Icons.logout_rounded),
                title: const Text("Logout",style: TextStyle(color: Colors.black,fontSize: 18),),
                onTap: () async {
                  PanaraConfirmDialog.show(
                    context,
                    title: "Do you want logout?",
                    message:"",
                    confirmButtonText: "Confirm",
                    cancelButtonText: "Cancel",
                    onTapCancel: () {
                      Navigator.pop(context);
                    },
                    onTapConfirm: () async{
                      await authService.signOut();
                      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context)=> const LoginPage()), (route) => false);
                    },
                    panaraDialogType: PanaraDialogType.normal,
                    barrierDismissible: false, // optional parameter (default is true)
                  );
                },
              ),
            ],
          )
      ),


      body: Container(
        padding: const EdgeInsets.symmetric(horizontal: 40,vertical: 17),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(
              Icons.account_circle_rounded,
              size:250,
              color: Colors.grey[700],
            ),
            const SizedBox(height: 30,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children:[
                const Text("Full Name",style: TextStyle(fontSize: 19),),
                Text(widget.userName,style: const TextStyle(fontSize: 19),)
              ],
            ),
            const SizedBox(height: 30,),
            const Divider(height: 8,),
            const SizedBox(height: 30,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children:[
                const Text("Email",style: TextStyle(fontSize: 19),),
                Text(widget.email,style: const TextStyle(fontSize: 19),)
              ],
            )
          ],
        ),
      ),
    );
  }
}
